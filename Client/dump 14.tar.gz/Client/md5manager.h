int getMD5checkSum(const char *filename, char* buffer);
